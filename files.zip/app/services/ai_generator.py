import os
from dotenv import load_dotenv
from openai import OpenAI
from app.schemas import IdeaInput, BusinessPlanOutput

load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def generate_business_plan(data: IdeaInput) -> BusinessPlanOutput:
    prompt = (
        f"Startup Idea: {data.idea}\n"
        f"Business Model: {data.business_model}\n"
        f"Industry: {data.industry}\n\n"
        "Generate a detailed business plan with:\n"
        "- Elevator Pitch\n"
        "- Market Analysis\n"
        "- Investor Attraction Strategy\n"
        "- Growth Projections"
    )

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.7
    )

    content = response.choices[0].message.content

    # Simple sectioning logic (can be improved later)
    parts = content.split("\n\n")
    return BusinessPlanOutput(
        pitch=parts[0] if len(parts) > 0 else "",
        market_analysis=parts[1] if len(parts) > 1 else "",
        investor_section=parts[2] if len(parts) > 2 else "",
        projections=parts[3] if len(parts) > 3 else "",
    )