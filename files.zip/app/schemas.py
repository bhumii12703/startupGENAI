from pydantic import BaseModel

class IdeaInput(BaseModel):
    idea: str
    business_model: str
    industry: str

class BusinessPlanOutput(BaseModel):
    pitch: str
    investor_section: str
    market_analysis: str
    projections: str