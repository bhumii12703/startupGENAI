from fastapi import APIRouter
from app.schemas import IdeaInput, BusinessPlanOutput
from app.services.ai_generator import generate_business_plan

router = APIRouter()

@router.post("/", response_model=BusinessPlanOutput)
def generate_plan(input: IdeaInput):
    return generate_business_plan(input)