from fastapi import FastAPI
from app.routes import generator

app = FastAPI(title="StartupGenAI Backend")

app.include_router(generator.router, prefix="/api/generate", tags=["Generate"])